let a = prompt('string typidagi malutni kiriting')
let b = +prompt('number typidagi malutni kiriting')
let c = prompt('boolean typidagi malutni kiriting')
alert('siz kiritgan malumot uchun rahmat (❤´艸｀❤)')

console.log(typeof a);
console.log(typeof b);
console.log(typeof c);


